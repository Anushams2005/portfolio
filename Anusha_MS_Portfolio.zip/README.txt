ANUSHA M S - PORTFOLIO

How to open:
1. Extract the ZIP file.
2. Open the folder.
3. Double-click index.html.
4. The portfolio will open in your web browser.

To publish it online:
You can upload the index.html to GitHub Pages, Netlify, or another static website hosting service.
